﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;//By Default for this application
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Demo_ADO_NET_DATA_GRID
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //creating a Connection Object
            string connectionString = "Data Source=PARTH-PC;Initial Catalog=master;Integrated Security=True";
            SqlConnection myConnection = new SqlConnection();
            myConnection.ConnectionString = connectionString;

            myConnection.Open();

            //creating a SQL string and Data adapter object
            string queryString = "select * from Student";
            SqlDataAdapter mydataAdapter = new SqlDataAdapter(queryString, myConnection.ConnectionString);

            //myConnection.Close();

            //creating dataset/datatable andf filling it
             DataSet dataSet = new DataSet("Student1");
            //DataTable dt = new DataTable("student1");
            //mydataAdapter.Fill(dt);
            mydataAdapter.Fill(dataSet);
           
            //Binding the DataGrid control to DataSet
            dataGridView1.DataSource = dataSet.Tables[0];//Showing the First table of the Dataset

            //myConnection.Dispose();
            
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'masterDataSet.Student' table. You can move, or remove it, as needed.
            this.studentTableAdapter.Fill(this.masterDataSet.Student);
            

        }
    }
}
