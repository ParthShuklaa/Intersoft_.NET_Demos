﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Linq;
using System.Data.Linq.Mapping;

namespace DEMO_LINQ_to_OBJECT_QUERY
{

    [Table(Name ="SalesLT.Customer")]
    public class Contact
    {
        [Column]
        public string Title;
        [Column]
        public string FirstName;
        [Column]
        public string LastName;

    }
    public partial class LINQ_to_SQL : Form
    {
        public LINQ_to_SQL()
        {
            InitializeComponent();
        }

        private void LINQ_to_SQL_Load(object sender, EventArgs e)
        {
            
            //connection string 
            string conn = "Data Source=PARTH-PC;Initial Catalog=AdventureWorksLT2017;Integrated Security=True";
            try
            {
                //Creating Data Context
                DataContext db = new DataContext(conn);
                Table<Contact> contacts = db.GetTable<Contact>();//Retunrs the table of similar type

                //Query DB
                var contactDetails = 
                                       from c in contacts
                                       where c.Title == "Mr."
                                       orderby c.FirstName
                                       select c;

                //DISPLAY Contact details
                foreach (var c  in contactDetails)
                {
                    //textBox1.AppendText(c.Title);
                    //textBox1.AppendText("\t");
                    textBox1.AppendText(c.FirstName);
                    textBox1.AppendText("\t \t");
                    textBox1.AppendText(c.LastName);
                    textBox1.AppendText("\n");
                    textBox1.AppendText("\n");
                }
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
        }
    }
}
