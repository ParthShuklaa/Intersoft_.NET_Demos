﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DEMO_LINQ_to_OBJECT_QUERY
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //Defining a String Array
            string[] names = {" Wings of FIRE",
                                "Rich Dad Poor Dad ",
                                "Deepwork", 
                                "Think Rich Grow MORE",
                                "Every One You hate is going to DIE"};
            //LINQ Query

            IEnumerable<string> AlltimeFavBooks  = from name in names
                                                   where name.Length >15
                                                   select name;
            //For each to display Objects
            foreach (var name in AlltimeFavBooks)
            {
                richTextBox1.AppendText(name + "\n");
            }
        }
    }
}
