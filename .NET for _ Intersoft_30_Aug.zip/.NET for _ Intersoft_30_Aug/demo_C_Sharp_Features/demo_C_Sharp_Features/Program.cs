﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace demo_C_Sharp_Features
{
    internal class Program
    {
        static void Main(string[] args)
        {
            /*Console.WriteLine( " \" here is the text to display ");
            Console.WriteLine(5 + 5);
            
            This is multiline comment
             */
            //Console.Write(" I am using write()");
            Console.WriteLine(" i am usig Writeline()");

            //const int myno = 20;
            //myno = 30;
            //Console.WriteLine(myno);

            double price = 49.99D;
            int x, y, z;
            x = y = z = 40;
            Console.WriteLine(x+y+z);

            Console.WriteLine("Price declared in double " +price);

            Console.ReadLine();
        }
    }
}
