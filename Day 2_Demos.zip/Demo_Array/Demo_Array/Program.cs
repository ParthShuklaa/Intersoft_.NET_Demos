﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_Array
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(" Working with Array");
            string[] mobilePhones = {"OnePlus","I Phone","Samsung","Redmi"};
            

            Console.WriteLine(mobilePhones[0]);//Displaying element
            mobilePhones[1] = "BlackBerry";      //Changing Element 
            Console.WriteLine(mobilePhones[1]);

            //Displaying all the elements of the array using forloop
            for (int i = 0; i < mobilePhones.Length; i++)
            {
                Console.WriteLine(mobilePhones[i]);
            }
            Console.WriteLine(mobilePhones.Length);

            //Displaying elements using Foreach loop
            foreach (var item in mobilePhones)
            {
                Console.WriteLine(item);
            }
            //sorting of an array
            Console.WriteLine("*****************************SORTING AN ARRAY******************************************");
            Array.Sort(mobilePhones);
            foreach (var item in mobilePhones)
            {
                Console.WriteLine(item);
            }
        }
    }
}
