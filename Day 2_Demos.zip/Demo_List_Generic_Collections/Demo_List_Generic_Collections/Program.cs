﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_List_Generic_Collections
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Implementating Genric List Collection");
            //Step1: Creating a List Collection
            //Step2: Adding Element to collection
            //Step3: Displaying element of collection

            var movies = new List<string>();
            movies.Add("END GAME");
            movies.Add("john wick");
            movies.Add("interstellar");
            movies.Add("Die hard");
            movies.Add("inception");

            Console.WriteLine(movies.Capacity);
            Console.WriteLine(movies.Count);
            Console.WriteLine(movies);

            foreach (var item in movies)
            {
                Console.WriteLine(item);
            }

            movies[0] = "INFINITY WAR";

            foreach (var item in movies)
            {
                Console.WriteLine(item);
            }

            Console.WriteLine( movies.Contains("INFINITY WAR"));
            Console.WriteLine("########## After Rmoving Die Hard Movie ########################");
            movies.Remove("Die hard");
            foreach (var item in movies)
            {
                Console.WriteLine(item);
            }
            movies.RemoveAt(1);
            foreach (var item in movies)
            {
                Console.WriteLine(item);
            }
        }
    }
}
