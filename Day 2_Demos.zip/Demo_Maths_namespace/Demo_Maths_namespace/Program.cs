﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_Maths_namespace
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(Math.Sqrt(169));
            Console.WriteLine(Math.Min(40, 70));
            Console.WriteLine(Math.Abs(-5.99));
            Console.WriteLine(Math.Round(9.99));
            Console.WriteLine(Math.Abs(-2147483));

        }
    }
}