﻿using System;

namespace Demo_Equality_Value_Ref
{
    public struct MyStruct
    {
        public int Id { get; set; }
        public string name { get; set; }

    };
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Implementing Equality in C#!");
            Member Obj1 = new Member { Id = 1, Name="Ronalado", Address="Portugal"};
            Member Obj2 = new Member { Id = 2, Name="Ronalado", Address="Portugal"};
            Member Obj3 = Obj1; // here we have two ref for same memory location
            Console.WriteLine(" Lets Check If two Objects have Same or Unique values:\n");
            Console.WriteLine(Obj1 == Obj2);//if Both Objects point to the same location
            Console.WriteLine(Obj1.Equals(Obj2));
            Console.WriteLine(System.Object.ReferenceEquals(Obj1,Obj2));
            //If Object Instance are the Same instance or Not  

            Console.WriteLine(Obj1 == Obj3);
            Console.WriteLine(Obj1.Equals(Obj3));
            Console.WriteLine(System.Object.ReferenceEquals(Obj1, Obj3));

                Console.WriteLine("Comapring HashCode of two Objects...!!");
                Console.WriteLine(Obj1.GetHashCode());
                Console.WriteLine(Obj2.GetHashCode());
            Obj1 = Obj2;

            Console.WriteLine(" Lets Check If two Objects have Same or Unique values:\n");
            Console.WriteLine(Obj1 == Obj2);//if Both Objects point to the same location
            Console.WriteLine(Obj1.Equals(Obj2));
            Console.WriteLine(System.Object.ReferenceEquals(Obj1, Obj2));

            Console.WriteLine("Comapring HashCode of two Objects...!!");
            Console.WriteLine( Obj1.GetHashCode());
            Console.WriteLine(Obj2.GetHashCode());

            Console.WriteLine("Implementing  Value type equality using Structure...!!!");

            MyStruct mystruct1 = new MyStruct { Id = 1, name = "Sachin" };
            MyStruct mystruct2 = new MyStruct { Id = 1, name = "Sachin" };
            // Console.WriteLine(mystruct1 == mystruct2);//Compile time error
            Console.WriteLine(System.Object.ReferenceEquals(mystruct1,mystruct2));
            Console.WriteLine(mystruct1.Equals(mystruct2));//Checking for value
        }
    }
}
