﻿using System;
namespace DEmo_Exception_Handling
{
    internal class Program : System.Exception
    {


        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
            

            try
            {
                int[] arr = { 1, 2, 3, 4, 5, 6, };

                //Displaying it
                for (int i = 0; i < arr.Length; i++)
                {
                    Console.WriteLine(arr[i]);
                }

                Console.WriteLine(arr[10]);
            }
            catch (IndexOutOfRangeException e)
            {
                Console.WriteLine(" An Exception Has occured : {0},{1}",e.Message,e.StackTrace);
               // throw;
            }
        }
    }
}
