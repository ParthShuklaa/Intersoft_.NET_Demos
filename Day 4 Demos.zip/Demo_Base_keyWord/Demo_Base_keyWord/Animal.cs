﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Demo_Base_keyWord
{
    internal class Animal
    {
        public string Color = "Yellow";
         public virtual void Speak()
        {
            Console.WriteLine(" Animal Speak from their heart.!!!");
        }
    }
     class Dog : Animal
    {
        string color = "black";
        public override void Speak()
        {
            Console.WriteLine(" Dogs are very talkative with their parents ...");
            Console.WriteLine($"base class speak() says :");
            base.Speak();
        }
        public void showcolor()
        {
            Console.WriteLine($"Color coming from base class is {base.Color}");
            Console.WriteLine($"Color define in current class is {color}");
        }
    }
}
