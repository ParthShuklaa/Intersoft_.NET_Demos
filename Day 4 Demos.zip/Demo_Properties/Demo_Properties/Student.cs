﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_Properties
{
    internal class Student
    {
        private string[] names = new string[25];//An Array of strings 
        public string this [int i]//We can list of arguments as parameters
        {
            get { return names [i]; }
            set { names [i] = value; }
        }

        public int AdhaarCarNo
        {
            get { return 1233212344; }// Read Only Property 
        }
        public int Id { get; set; }//In this implementation, private field is automatically declared
        private string FaceBookLink;//Private Field
        private string name;//private field
        public string Name //Defining Property
        {
            get { return name; }
            set { name = value; }
        }

        public Student( string name, int Id)
        {
            this.name = name;
            this.Id = Id;
        }
       static public int SchoolbusNo { get; set; }//we can define static property
    }
}
