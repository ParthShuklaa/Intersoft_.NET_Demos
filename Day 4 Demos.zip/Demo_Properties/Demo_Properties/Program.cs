﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_Properties
{
    internal class Program
    {
        
        static void Main(string[] args)
        {
            Console.WriteLine("Implementing Properties...");

            Student newStudent = new Student("Karan",2);
            //newStudent.Id = 1;
            //newStudent.Name = "Aman";
           // newStudent.AdhaarCarNo = "789987";

            Console.WriteLine($"  Student ID  : {newStudent.Id} & Student Name : {newStudent.Name} , Card details:{newStudent.AdhaarCarNo}");

            newStudent[0] = "Yami";//implementation using indexes
            newStudent[1] = "Peter";
            newStudent[2] = "Gautam";
            for (int i = 0; i < 10; i++)
            {
                Console.WriteLine(newStudent[i]);
            }

            //foreach (var item in newStudent)
            //{
            //    Console.WriteLine(item);
            //}
        }
    }
}
