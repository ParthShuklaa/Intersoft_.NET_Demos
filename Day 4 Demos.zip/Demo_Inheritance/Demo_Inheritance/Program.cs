﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_Inheritance
{
    internal class Program
    {
        static void Main(string[] args)
        {
            newChild child1 = new newChild();
            child1.read("Akshay", "Martial Arts");
            CousinClass cousin1 = new CousinClass();
            cousin1.read("Vijay", "Judo");
        }
    }
}
