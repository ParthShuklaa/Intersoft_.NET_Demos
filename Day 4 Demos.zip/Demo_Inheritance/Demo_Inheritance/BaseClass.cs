﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_Inheritance
{
    internal class BaseClass
    {
        public string name;
        public string subject;
        public BaseClass()
        {
            Console.WriteLine(" i am a Base class constructor...!!!!");
        }
        public void read(string name, string subject)
        {
            this.name = name;
            this.subject = subject;
            Console.WriteLine($"I am {name} and my subject is {subject}");
        }
    }
   class Child : BaseClass
    {
        public Child()
        {
            Console.WriteLine("This is my Child class...!!!");
        }
    }
    class newChild : Child
    {
        public newChild()
        {
            Console.WriteLine(" I am Inside new child class via multilevel inheritance");
        }
    }
}
