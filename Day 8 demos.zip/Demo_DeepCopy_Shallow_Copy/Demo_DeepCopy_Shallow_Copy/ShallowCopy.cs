﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_DeepCopy_Shallow_Copy
{
    internal class ShallowCopy : ICloneable
    {
        public int I { get; set; }
        public int J { get; set; }

        public object Clone()
        {
           return this.MemberwiseClone();
        }
    }
}
