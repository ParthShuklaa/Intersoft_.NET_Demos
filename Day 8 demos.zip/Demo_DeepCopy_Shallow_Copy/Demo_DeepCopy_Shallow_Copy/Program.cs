﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_DeepCopy_Shallow_Copy
{
    internal class Program
    {

        static void Main(string[] args)
        {
            Console.WriteLine(" Deep Copying taking place As memory ref is same ");
            ShallowCopy obj = new ShallowCopy();
            ShallowCopy objClone = obj;
            obj.I = 101; //Setting obj value after cloning
            Console.WriteLine("objvalue:{0} \t Clone Value :{1}", obj.I, objClone.I);

            Console.WriteLine("________________________After Implementing Shallow Copying using Clone()______________________________");
            ShallowCopy obj2 = (ShallowCopy)obj.Clone();
            obj.I = 201;
            Console.WriteLine("After using MemberWiSeClone(){0}",obj2.I);
        }
    }
}
