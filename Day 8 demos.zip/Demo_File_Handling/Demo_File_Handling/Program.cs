﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_File_Handling
{
    internal class Program
    {

        static void Main(string[] args)
        {
            Console.WriteLine(" Working with Streams - Sequence of byte");

            FileWrite wr = new FileWrite();
            wr.WriteData();
            Console.WriteLine("Reading Data from the file ");
            wr.ReadData();

        }
    }
}
