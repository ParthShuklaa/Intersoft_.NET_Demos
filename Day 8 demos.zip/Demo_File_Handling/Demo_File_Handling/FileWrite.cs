﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Contracts;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_File_Handling
{
    internal class FileWrite
    {
        public void WriteData()
        {
            //Step 1 : Creating Object of File Stream for writing into a file
            //Step 2 : Creating the object of Stream Writer and passing File stream object as parameter 
            //Step 3 : Asking user for the text message and saving it to Stream Writer object
            //Step 4 : Closing Stream Writer and File Stream using Close()
            
            FileStream fs = new FileStream("C:\\Users\\dell\\source\\repos\\.NET for _ Intersoft_30_Aug\\Day 8\\Demo_File_Handling\\Demo_File_Handling\\myDetails.txt", FileMode.Append, FileAccess.Write);
            StreamWriter sw = new StreamWriter(fs);
            Console.WriteLine(" Enter the Text...");
            string str = Console.ReadLine();
            sw.WriteLine("\n"+str);
            sw. Flush();
            sw.Close();
            fs.Close();
        }
        public void ReadData()
        {
            FileStream fs = new FileStream("C:\\Users\\dell\\source\\repos\\.NET for _ Intersoft_30_Aug\\Day 8\\Demo_File_Handling\\Demo_File_Handling\\myDetails.txt",FileMode.Open, FileAccess.Read);
            StreamReader sr = new StreamReader(fs);
            string str = sr.ReadToEnd();
            Console.WriteLine(str);
            
            //sr.Close();
            //fs.Close();
        }
    }
}
