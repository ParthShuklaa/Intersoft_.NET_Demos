﻿using System;

namespace DEmo_Memory_Management
{
    internal class Program
    {
        public static void Free()
        {
            Complex C3 = new Complex();//Object with Zero refrence for calling GC

        }
        static void Main(string[] args)
        {
            Console.WriteLine("Destructors in C#");

            Complex C = new Complex();
            C.SetValue(4, 7);
            C.DisplayValue();
            Complex C1 = new Complex();
            C1.DisplayValue();
            Console.WriteLine(" End of Code...");
            Console.ReadKey();
            C1.Dispose();

        }
    }
}
