﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DEmo_Memory_Management
{
    //iDisposible interface contains Dispose() for realeasing unmanageble resources files, connection string, Streams etc
     class Complex : IDisposable
    {
        int real, imaginary;

        public Complex()
        {
            real = 0;
            imaginary = 0;
            Console.WriteLine("Objects Initilized with null Values using constructor..!!");
        }

        public void SetValue(int r, int i)
        {
            real = r;
            imaginary = i;
        }
        public void DisplayValue()
        {
            Console.WriteLine("real ="+real);
            Console.WriteLine("Imaginary ="+imaginary);
            
        }

        public void Dispose()
        {
            Dispose(true);
            Console.WriteLine(" Dispose() is called  to dispose unmanaged reosurces..");
            GC.SuppressFinalize(this);
            //it is called to prevent the garbage collector  from running the finalizer
            
        }

        protected virtual void Dispose(bool disposing)
        {
            if (disposing)
                Console.WriteLine(" Cleaning up all managed resources - along with child objects implemting IDisposible interface");
        }
        ~Complex()
        {
            Console.WriteLine("Destructor was called ...!!!");
            //C# complier will covert this destructor method in finalize method
            Dispose(false);
        }
    }
}
