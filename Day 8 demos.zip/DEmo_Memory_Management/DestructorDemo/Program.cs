﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DestructorDemo
{
    class Complex
    {
        int real, imaginary;

        public Complex()
        {
            real = 0;
            imaginary = 0;
            Console.WriteLine("Objects Initilized with null Values using constructor..!!");
        }

        public void SetValue(int r, int i)
        {
            real = r;
            imaginary = i;
        }
        public void DisplayValue()
        {
            Console.WriteLine("real =" + real);
            Console.WriteLine("Imaginary =" + imaginary);
        }
        ~Complex()
        {
            Console.WriteLine("Destructor was called ...!!!");
        }
    }
    internal class Program
    {
        public static void Free()
        {
            Complex C3 = new Complex();//Object with Zero refrence for calling GC

        }
        static void Main(string[] args)
        {
            Console.WriteLine("Destructors in C#");

            Complex C = new Complex();
            C.SetValue(4, 7);
            C.DisplayValue();
            //Complex C1 = new Complex();
            //C1.DisplayValue();
            //Console.WriteLine(" End of Code...");
            //GC.Collect();
            using (TextWriter txt = File.CreateText("MyFile.Txt"))
            {
                txt.WriteLine("Hi Every One...:");
            }
            

        }
    }
}
