﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_ObjectPooling
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Factory fa = new Factory();
            Employee myEmp = fa.GetEmployee();
            Console.WriteLine("First Object is Created ...!!!!");
            Employee MyEmp1 = fa.GetEmployee();
            Console.WriteLine("Second Object is created ...!!!");
            Employee myemp3 = fa.GetEmployee();
            Console.WriteLine(" Third Object is created ...!!!");
            


        }
    }
}
