﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_ObjectPooling
{
    internal class Factory
    {
        private static int _PoolMaxSize = 2;
        private static readonly Queue ObjPool = new Queue(_PoolMaxSize);
        public Employee GetEmployee()
        {
            Employee OEmployee = new Employee();
            if (Employee.Counter >= _PoolMaxSize && ObjPool.Count>0)
            {
                OEmployee = RetriveFromPool();
            }
            else
            {
                OEmployee = GetNewEmployee();
            }
            return OEmployee;
        }
         protected Employee RetriveFromPool()
        {
            Employee OEmp;
            //If there is nay object in my collection
            if (ObjPool.Count >0)
            {
                OEmp = (Employee)ObjPool.Dequeue();
                Employee.Counter--;
                Console.WriteLine("This Object is coming from the pool of Object ");
            }
            else
            {
                //returning a new Object
                OEmp = new Employee();
            }
            return (OEmp);
        }

        private Employee GetNewEmployee()
        {
            Console.WriteLine(" new Object is created ");
            //Creating a New Employe
            Employee OEmp = new Employee();
            ObjPool.Enqueue(OEmp);
            return OEmp;
            
        }


    }
    internal class Employee
    {
        public static int Counter = 0;
        public Employee()
        {
            ++Counter;
        }
        private string _FirstName;
        public string Firstname
        {
            get
            {
                return _FirstName;
            }
            set
            {
                _FirstName = value;
            }
        }
    }
}
