﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace DEmo_LINQ_XML
{
    internal class Program
    {
        string path = "D:\\Demo\\ParticipantsDetails.xml";
        private void GETXMLData()
        {
            //Step 1:Connection String

            try
            {
                

                XDocument doc = XDocument.Load(path);
                // XDocument  doc  = XDocument.Parse(path);
                var students = from participant in doc.Descendants("Partcipant")
                               select new
                               {
                                   ID = Convert.ToInt32(participant.Attribute("ID").Value),
                                   Name = participant.Element("Name").Value
                               };
                //Console.WriteLine("Executing For each now ..!!" + students.Count());
                foreach (var student in students)
                {
                    Console.WriteLine(student.ID + "-" + student.Name);
                   // Console.WriteLine("Running Foreach");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);

            }
        }
        private void InsertXMLData(string name)
        {
            try
            {
                XDocument myXML = XDocument.Load(path);
                XElement newParticipant = new XElement("Partcipant", new XElement("Name", name));
                var LastStudent = myXML.Descendants("Partcipant").Last();//Gets the last element 
                int newID = Convert.ToInt32(LastStudent.Attribute("ID").Value); //It gets the ID of last element 

                newParticipant.SetAttributeValue("ID", newID +1);//Setting Attribute

                myXML.Element("Partcipants").Add(newParticipant);//Adding New Element
                myXML.Save(path); // Saving changes
            }
            catch (Exception)
            {

               
            }
        }

        private void ModifyXMLData( string name, int Id)
        {
            try
            {
                XDocument testXML =  XDocument.Load(path);
                XElement CParticipant = 
                    testXML.Descendants("Partcipant").Where(c => c.Attribute("ID").Value.Equals(Id.ToString())).FirstOrDefault();

                //CParticipant.Element("Name").Value = name;
                CParticipant.SetElementValue("Name", name);
                testXML.Save(path);
            
            
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.StackTrace);
            }
        }

        private void  DeleteXMLData( int id)
        {
            try
            {
                XDocument testxml = XDocument.Load(path);
                XElement dparticipant = testxml.Descendants("Partcipant").Where(c=> c.Attribute("ID").Value.Equals(id.ToString())).FirstOrDefault();
                dparticipant.Remove();
                testxml.Save(path);
            
            }
            catch (Exception ex)
            {

                Console.WriteLine(ex.Message);
            }
        }
        static void Main(string[] args)
        {
            Console.WriteLine("Implementing LINQ to XML");
            
            Program obj1 = new Program();
            obj1.GETXMLData();

            //obj1.InsertXMLData("Sasikant");
            //obj1.GETXMLData();

            //obj1.InsertXMLData("Khushboo");
            //obj1.GETXMLData();

            //obj1.ModifyXMLData("Srishty", 4);
            //Console.WriteLine("___________________Modifying XML Data using LINQ____________________________________");
            //obj1.GETXMLData();

            obj1.DeleteXMLData(5);
            Console.WriteLine("********************DELETING XML ELEMENT******************");
            obj1.GETXMLData();
        }

    }
}
