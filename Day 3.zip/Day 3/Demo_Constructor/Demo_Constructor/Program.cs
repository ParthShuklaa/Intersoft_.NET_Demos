﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_Constructor
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Demo_Constructor Implementing Constructor");

            Employee emp1 = new Employee();//Default Construcrtor
            Console.WriteLine(emp1.dept);
            Employee emp2 = new Employee(); 
            Console.WriteLine(emp2.dept);
            emp1.dept = "Sales";//changing the default value intilized by contructor
            Console.WriteLine(emp1.dept);

            Employee emp3 = new Employee("VIRAT", "Media and Communication");//parameterised constructor
            Console.WriteLine($" Employee 3 is {emp3.name} and its dept is {emp3.dept}");
        }
    }
}
