﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;

namespace Demo_FunctionOverloading
{    
    class Car
    {
        public string Color = "Yellow";
        int maxSpeed = 290;
        public string modelName;
        public string ModelNo;
    }
    internal class Program //: Student // Inheriting class Student
    {
        //static int Add(int x, int y)
        //{
        //    return x + y;
        //}

        //static void Add(int x, int y) Not a Function overloading 
        //{
        //    Console.WriteLine( x+y);
        //}

        //static int Add ( int z)
        //{
        //    Console.WriteLine();
        //}

        static float Add(float x , float y)
        {
            return (x + y);
        }

        static string Add( string x , string y)
        {
            return (x + y);
        }
        static void Main(string[] args)
        {
            Console.WriteLine("Function Overloading Demo ");

            Console.WriteLine( "Calling INT based Add function" +Add(25, 55));
            Console.WriteLine("Calling Float based ADD function" +Add(12.8f, 17.94f));
            Console.WriteLine("Calling String based ADD Function "+ Add("Good" , "Luck"));
            Student s1 = new Student(); //parent class Object
            Program P1 = new Program();
            s1.StudentMesssage();
            //P1.StudentMesssage();// Not possible  beacuse program class object has no reference of student class fucntion

            Car objcar = new Car();
            Console.WriteLine(objcar.Color);

            Car Mycar = new Car();
            Mycar.ModelNo = "747";
            Mycar.modelName = "FERARI";
            Console.WriteLine($"{Mycar.modelName} is the name and {Mycar.ModelNo} and color is {Mycar.Color}");

        }
    }
}
