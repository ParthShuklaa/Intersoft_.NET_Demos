﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace First_Space
{
    class Namespace1
    {
      public  void func()
        {
            Console.WriteLine("Inside the First NameSpace...!!!");
        }
    }

    namespace Second_Space
    {
        class Namespace_2
        {
            public void func()
            {
                Console.WriteLine("Inside the second Namespace...!!!");
            }
        }
    }
}
namespace Demo_NameSpace
{
    internal class Program
    {
        static void Main(string[] args)
        {
                First_Space.Namespace1 fc = new First_Space.Namespace1();
                First_Space.Second_Space.Namespace_2 sc = new First_Space.Second_Space.Namespace_2();
            sc.func();
            fc.func();
            
        }
    }
}
