﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_String
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("String IMplemtation....");
            string mystring = "TEST";
            Console.WriteLine(mystring.Length);
            Console.WriteLine(mystring.Count());
            Char[] mystring1 = { 'T', 'E', 'S', 'T' };
            Console.WriteLine(mystring);
            Console.WriteLine(mystring1.ToString());
            Console.WriteLine( mystring.CompareTo(mystring1.ToString()));
            
            //Clone - Getting the ref to the instance of string
            //Compare - To compare two specified string object to get an integer which
            //represent their relative position in the sorted order

            Console.WriteLine(mystring.Equals(mystring1.ToString()));

            //if (mystring == mystring1.ToString())
            //{
            //    Console.WriteLine(" Both string are same..!!!");
            //}
            //else
            //{
            //    Console.WriteLine("They are different..!!");
            //}

            Console.WriteLine( mystring.Substring(0, 3));
            Console.WriteLine(mystring.ToLower());
            Console.WriteLine(mystring.Replace('S', 'X'));
            Console.WriteLine(mystring.GetHashCode());

            StringBuilder mysb = new StringBuilder("Hello World", 50);
            Console.WriteLine(mysb);
            mysb.Append(" Hope You are learning something new");
            Console.WriteLine(mysb.Length);
            mysb.AppendLine(" in C#");
            mysb.Append("and ASP.NET");
            Console.WriteLine(mysb.Length);
            Console.WriteLine();
            Console.WriteLine(mysb);

            StringBuilder SbAmount = new StringBuilder("Your Total Amont is :");
            SbAmount.AppendFormat(" 1) {0}", 250);
            Console.WriteLine(SbAmount);



         }
    }
}
