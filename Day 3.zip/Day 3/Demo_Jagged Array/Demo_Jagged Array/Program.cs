﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_Jagged_Array
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("dEMO jAGGED aRRAY...."   );

            int[][] myarr = new int[3][];
            myarr[0] = new int[4] {11,21,31,41};
            myarr[1] = new int[6] {12,22,32,42,52,62};
            myarr[2] = new int[] { 13, 14, 15, 16, 17, 18, 19, 20 };

            foreach (var item in myarr)
            {
                Console.WriteLine();
                foreach (var item1 in item)
                {
                    Console.Write(item1+" ");
                }
            }
        }
    }
}
