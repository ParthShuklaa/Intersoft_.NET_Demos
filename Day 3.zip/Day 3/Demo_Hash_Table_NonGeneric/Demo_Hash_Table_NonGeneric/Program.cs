﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_Hash_Table_NonGeneric
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hash Table Implementation - Non Genric Collection Class");

            Hashtable myht = new Hashtable();
            myht.Add(1, "TOM CRUISE");
            myht.Add(2, "TOM HIDDLESTONE");
            myht.Add(3, "TOM FURY");

            myht.Add(250, "John Lenon");
            myht.Add("Admin", "SuperAdmin");
            myht.Add(true, "Catchmeifyoucan");
            myht.Add(4, "Tom Altor");
            foreach (DictionaryEntry item in myht)
            {
                Console.WriteLine($"key: {item.Key},Value: {item.Value}");
            }

            myht.Remove(2);
            Console.WriteLine("__________After removing an element from the collection_____________");
            foreach (DictionaryEntry item in myht)
            {
                Console.WriteLine($"key: {item.Key},Value: {item.Value}");
            }

            Console.WriteLine( myht.Contains(4));
            Console.WriteLine(myht.ContainsValue("John Lenon"));

        }
    }
}
