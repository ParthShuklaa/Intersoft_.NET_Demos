﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Demo_Param_Keyword
{
    internal class Program
    {
        public void Show( params int[] val)
        {
            for (int i = 0; i < val.Length; i++)
            {
                Console.WriteLine(val[i]);
            }

            //Create aa Function that accepts name, Age, Email and Adress of an Emp using Array
            
        }

        static void Greeting( string Fname = "D. Beckham", int goals = 180)
        {
            Console.WriteLine(Fname +", Hi Good Morning..!!"+ goals);
        }

         static int Cal_Square(int x)
        {
            return x*x;
        }

        //Named Arguments
        //
         static void Display( string CEO, string Manager, string TestEngineer)//parameter
        {
            Console.WriteLine("Senior Most authority in a company is :" + CEO);
        }
        static void Main(string[] args)
        {
            Console.WriteLine("PARAM keyword ");
            Program myData = new Program();
            myData.Show(9, 8, 7, 6, 5, 4, 3, 2, 1, 10);

            Program newData = new Program();
            newData.Show(10, 20);

            Greeting("L.Messi",250);
            Greeting("B.Bhutia",150);
            Greeting();

            Console.WriteLine(Cal_Square(12));

            Display(TestEngineer: "Tom Cruise", CEO: "Nawazuddin Siddique", Manager: "Morgan Freeman");//Arguments




        }
    }
}
