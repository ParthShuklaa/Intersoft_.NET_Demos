﻿using System;
using System.Collections.Generic;

#nullable disable

namespace DEmoCRUD_CoreMVC_5_Framework.Models
{
    public partial class Student
    {
        public int StudentId { get; set; }
        public string StudentName { get; set; }
        public string StudentAddress { get; set; }
    }
}
