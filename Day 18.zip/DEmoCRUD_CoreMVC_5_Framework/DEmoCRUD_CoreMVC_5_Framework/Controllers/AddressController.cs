﻿using DEmoCRUD_CoreMVC_5_Framework.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Diagnostics;
using System.Threading.Tasks;

namespace DEmoCRUD_CoreMVC_5_Framework.Controllers
{
    public class AddressController : Controller
    {
        private readonly AdventureWorksLT2017Context _context;

        public AddressController(AdventureWorksLT2017Context context)
        {
            _context = context;
        }


        // GET: AddressController
        public async Task<IActionResult> Index()
        {
            //Returing list of Adress in asynchronous manner
            var addresses = await _context.Addresses.ToListAsync();
            return View(addresses);
        }

        // GET: AddressController/Details/5
        public  async Task<IActionResult> Details(int? addressId)
        {
            if (addressId == null)
            {
                return NotFound();
            }
            var address = await _context.Addresses.FirstOrDefaultAsync(x => x.AddressId == addressId);
            if (address == null)
            {
                return NotFound();
            }
            return View(address);
        }

        public async Task<IActionResult> AddOrEdit(int? addressId)
        {
            ViewBag.PageName = addressId == null ? "Create Address" : "EditAddress";
            ViewBag.IsEdit = addressId == null ? false : true;
            if (addressId == null)
            {
                return View();
            }
            else
            {
                var address = await _context.Addresses.FindAsync(addressId);
                if (address == null)
                {
                    return NotFound();
                }

                return View(address);
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        //[ModelBinder(Binder)]
        public async Task<IActionResult> AddOrEdit(int addressId, [Bind("AddressId,AddressLine1,City,StateProvince,CountryRegion")] Address addressData)

        {
            bool IsAddressExist = false;
            Address address = await _context.Addresses.FindAsync(addressId);

            if (address!=null)
            {
                IsAddressExist = true;
            }
            else
            {
                address = new Address();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    address.AddressLine1 = addressData.AddressLine1;
                    address.City = addressData.City;
                    address.StateProvince = addressData.StateProvince;
                    address.CountryRegion = addressData.CountryRegion;
                    if (IsAddressExist)
                    {
                        _context.Update(address);
                    }
                    else
                    {
                        _context.Add(address);
                    }
                    await _context.SaveChangesAsync();

                }
                catch (DbUpdateConcurrencyException)
                {
                    throw;

                }
                return RedirectToAction(nameof(Index));
            }
            return View(addressData);
        }
        // GET: AddressController/Create
        //[Bind(String)] - its a way to bind model 
        public ActionResult Create()
        {
            return View();
        }

        // POST: AddressController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: AddressController/Edit/5
        public ActionResult Edit(int id)
        {
            return View();
        }

        // POST: AddressController/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(int id, IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: AddressController/Delete/5
        public async Task<IActionResult> Delete(int? addressId)
        {
                if (addressId == null)
                {
                    return NotFound();
                }
                var address = await _context.Addresses.FirstOrDefaultAsync(x => x.AddressId == addressId);
            if (address == null)
            {
                return NotFound();
            }
            return View(address);
           
        }

        // POST: AddressController/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public  async Task <IActionResult> Delete(int addressId)
        {
            var address = await _context.Addresses.FindAsync(addressId);
            _context.Addresses.Remove(address);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }
    }
}
