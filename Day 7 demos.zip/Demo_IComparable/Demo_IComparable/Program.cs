﻿using System;

namespace Demo_IComparable
{
    internal class Program
    {
        
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
            Car[] arrayofCars = new Car[5]
            {
                new Car("Honda", 1977),
                new Car("Ford", 1932),
                new Car ("Fiat",1988),
                new Car("Ferari",1985),
                 new Car("BMW", 1960)
            };

            Console.WriteLine(" Arrays  in Unsorted way\n");

            foreach (Car c  in arrayofCars)
            {
                Console.WriteLine(c.name + "\t\t" +c.year);
            }

        }
    
}
