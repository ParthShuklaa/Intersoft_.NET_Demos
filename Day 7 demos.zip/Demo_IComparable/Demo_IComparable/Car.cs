﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;

namespace Demo_IComparable
{
    internal class Car : IComparable
    {
        class SortYearAscendingHelper : IComparer
        {
            public IComparer.Compare(Object a, Object b)
            {
                Car c1 = (Car)a;
            Car c2 = (Car)b;
                
                if (c1.year > c2.year)
                {
                return 1;
                }
                else if (c1.year<c2.year)
                  {
                return -1;
                }
                else
                    {
                return 0;
                    }
             }
        }
        class SortNameDescendingHelper : IComparer
            {
        int IComparer.Compare(object x, object y)
                {

            Car c1 = (car)x;
            Car c2 = (car)y;
            return String.Compare(c2.name, c1.name);

                }


            }
        public int year { get; set; }
        public string name { get; set; }
        int IComparable.CompareTo(object? obj)
        {
            Car c = (Car)obj;
            return String.Compare(this.name, c.name);
        }
        public static IComparer SortYearAscending()
        {
            return (IComparer)new SortYearAscendingHelper();
        }

        public static IComparer SortnameAscending()
        {
            return (IComparer)new SortNameDescendingHelper();// CREATING REF VIA DEFAULT CONSTRUCTOR
        }
        
    
    


    
}