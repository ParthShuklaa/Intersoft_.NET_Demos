﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;

namespace Demo_IComparable
{
    //internal class SortYearAscendingHelper : IComparer
    //{
    //    int IComparer.Compare(object a,object b)
    //    {

    //    }
    //}


}
