﻿using System;

namespace Demo_Contravariance
{
    public delegate void mydelegate();//user define delegate 
    internal class Program
    {
        
        static void Setobject(object val1) { }
        static void SetString( string  val2) { }
        static void Main(string[] args)
        {
            Console.WriteLine("Contravariance delegates reverses the covariance functionality");

            Action<string> del1 = Setobject; //in-built generic type delegate
            
            //here a delagte specifies a parameter type as string,
            //still we assign a method that object as parameter
            //here it Is allowing  a method that parameter types less derived than
            //what is specified in the delegate
            Func<string> del2 = Setobject;
            Func<>


        }
    }
}
