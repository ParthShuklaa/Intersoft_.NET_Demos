﻿using System;
using System.Collections.Generic;

namespace Demo_IEnumerator_IEnumerable
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Working with IEnumerable Interface");

            List<string> Month = new List<string>();
            Month.Add("Jan");
            Month.Add("Feb");
            Month.Add("March");

            //creating IEnumerable string 
            IEnumerable<string> iEnumerableofString = Month;
            //using IEnumerable Object 
            foreach (string AllMonths in iEnumerableofString)
            {
                Console.WriteLine(AllMonths);
            }
            //Creating IEnumertor of string
            IEnumerator<string> iEnumeratorOfString = Month.GetEnumerator();

            Console.WriteLine("Implementing foreach() on IEnumerator string");
            foreach (string item in iEnumeratorOfString)
            {
                Console.WriteLine(item);
            }
            //Displaying all the items from IEnumerator Object 
            while (iEnumeratorOfString.MoveNext())
            {
                Console.WriteLine(iEnumeratorOfString.Current);
            }
            //Both Interface helps us in looping through the collection

            //Array MyArray;
            List mylist;  
        }
    }
}
