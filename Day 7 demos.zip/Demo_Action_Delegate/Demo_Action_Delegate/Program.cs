﻿using System;
using System.Runtime.CompilerServices;

namespace Demo_Action_Delegate
{
    internal class Program
    {
        public static void Display( string message)
        {
            Console.WriteLine(" Here We are  instantiating Action(T> delegate instead of explicityly defining a new delegate and assigning a named method to it.");
        }
        static void Main(string[] args)
        {
            Console.WriteLine("Action delegate working");

            Action<string> messagetarget;

            if (Environment.GetCommandLineArgs().Length >1)
            {
                messagetarget = Display;
            }
            else
            {
                messagetarget = Console.WriteLine;
                messagetarget(" Hello World - This is the else part of the condition");
            }

            
        }
    }
}
