﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
System.Diagnostics.Stopwatch;

namespace DEmo_Stop_Watch
{
    public partial class Form1 : Form
    {
        
        public Form1()
        {
            InitializeComponent();
            progressBar1.Value = 0;
            
        }

        private void button4_Click(object sender, EventArgs e)
        {
            //for (int i = 0; i < progressBar1.Maximum; i +=10)
            //{
            //    progressBar1.Value = i;
            //    Thread.Sleep(500);
            //}

            for (int i = 0; i < 59; i++)
            {
                Seconds_btn.Text = $"{i}";
               // Thread.Sleep(500);
            }

            
        }

        private void button5_Click(object sender, EventArgs e)
        {


            progressBar1.Value = 0;

        }
        //public  static void ShowProgress( bool flag )
        //{
        //    while (flag)
        //    {
        //        Form1 obj = new Form1();
        //        obj.progressBar1.Value += 25;

        //    }
        //}
    }
}
