﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Demo_Multithreading
{
    public class MyThread
    {
        public static void Thread1Display()
        {
            for (int i = 0; i < 3; i++)
            {
                Console.WriteLine("First Thread in Execution"+i);

            }
        }

        public static void Thread2Display()
        {
            for (int i = 0; i < 3; i++)
            {
                Console.WriteLine("Second Thread in Execution "+i);
            }
        }

        
    }
    internal class Program
    {
        static void Main(string[] args)
        {
           // Console.WriteLine(" Multithreading in Action ");


           // MyThread obj1 = new MyThread(); // Creating an Object of our class
            //Crating thread using thread class for calling non static method
            //Thread thread1 = new Thread(new ThreadStart(obj1.Thread1Display));
            //thread1.Start();
            Thread a = new Thread(MyThread.Thread1Display);
            Thread b = new Thread(MyThread.Thread2Display);
            a.Start();
            b.Start();
            Console.WriteLine(" Both Threads are running and executing corresponding process");
            //Console.WriteLine("Line 1");
            //Console.WriteLine("Line 2");
        }
    }
}
